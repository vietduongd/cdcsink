use serde::{Deserialize, Serialize};
use std::path::Path;

// Re-export flow config types from cdc-core
pub use cdc_core::{FlowConfig, ConnectorConfig, DestinationConfig};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AppConfig {
    pub flows: Vec<FlowConfig>,
    pub api: ApiConfig,
    pub logging: LoggingConfig,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ApiConfig {
    /// API server host
    pub host: String,
    
    /// API server port
    pub port: u16,
    
    /// Enable CORS
    pub cors_enabled: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct LoggingConfig {
    /// Log level (trace, debug, info, warn, error)
    pub level: String,
    
    /// JSON formatted logs
    pub json: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ApiConfig {
    /// API server host
    pub host: String,
    
    /// API server port
    pub port: u16,
    
    /// Enable CORS
    pub cors_enabled: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct LoggingConfig {
    /// Log level (trace, debug, info, warn, error)
    pub level: String,
    
    /// JSON formatted logs
    pub json: bool,
}

impl Default for AppConfig {
    fn default() -> Self {
        Self {
            flows: vec![FlowConfig::default()],
            api: ApiConfig {
                host: "0.0.0.0".to_string(),
                port: 3000,
                cors_enabled: true,
            },
            logging: LoggingConfig {
                level: "info".to_string(),
                json: false,
            },
        }
    }
}

impl Default for FlowConfig {
    fn default() -> Self {
        Self {
            name: "default-flow".to_string(),
            connector: ConnectorConfig {
                connector_type: "nats".to_string(),
                config: serde_json::json!({
                    "servers": ["nats://localhost:4222"],
                    "subject": "cdc.events",
                    "consumer_group": null,
                    "use_jetstream": false
                }),
            },
            destinations: vec![DestinationConfig {
                destination_type: "postgres".to_string(),
                config: serde_json::json!({
                    "url": "postgresql://postgres:postgres@localhost:5432/cdc",
                    "max_connections": 10,
                    "schema": "public",
                    "conflict_resolution": "upsert"
                }),
            }],
            batch_size: 100,
        }
    }
}

impl AppConfig {
    pub fn from_file(path: impl AsRef<Path>) -> anyhow::Result<Self> {
        let content = std::fs::read_to_string(path)?;
        let config = serde_yaml::from_str(&content)?;
        Ok(config)
    }
    
    pub fn to_file(&self, path: impl AsRef<Path>) -> anyhow::Result<()> {
        let content = serde_yaml::to_string(self)?;
        std::fs::write(path, content)?;
        Ok(())
    }
}
