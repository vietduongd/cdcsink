# Configuration Management System

The CDC system uses a three-tier configuration architecture for managing connectors, destinations, and flows.

## Directory Structure

```
config/
├── connectors.yaml      # Connector configurations
├── destinations.yaml    # Destination configurations
└── flows.yaml          # Flow configurations (references only)
```

## Configuration Files

### connectors.yaml

Defines connector configurations that can be reused across multiple flows.

```yaml
- name: nats-local
  connector_type: nats
  config:
    servers: ["nats://localhost:4222"]
    subject: "cdc.events"
  description: "Local NATS server"
  tags: [development, local]
```

**Fields:**

- `name`: Unique identifier for this connector config
- `connector_type`: Type of connector (nats, kafka, etc.)
- `config`: Connector-specific configuration (varies by type)
- `description`: Optional human-readable description
- `tags`: Optional tags for organization

### destinations.yaml

Defines destination configurations that can be reused across multiple flows.

```yaml
- name: postgres-local
  destination_type: postgres
  config:
    url: "postgresql://localhost/cdc"
    max_connections: 10
    schema: "public"
    conflict_resolution: "upsert"
  description: "Local PostgreSQL database"
  tags: [development, local]
```

**Fields:**

- `name`: Unique identifier for this destination config
- `destination_type`: Type of destination (postgres, mysql, etc.)
- `config`: Destination-specific configuration (varies by type)
- `description`: Optional human-readable description
- `tags`: Optional tags for organization

### flows.yaml

Defines flows by referencing connector and destination configurations.

```yaml
- name: local-dev-flow
  connector_name: nats-local # Reference to connector
  destination_names: # References to destinations
    - postgres-local
  batch_size: 100
  auto_start: true
  description: "Development flow"
```

**Fields:**

- `name`: Unique identifier for this flow
- `connector_name`: Name of connector config to use
- `destination_names`: List of destination config names
- `batch_size`: Batch size for writing
- `auto_start`: Start automatically on system startup
- `description`: Optional human-readable description

## Benefits

✅ **Config Reuse** - Define connector/destination once, use in multiple flows
✅ **Easy Management** - Update connector config affects all flows using it
✅ **Better Organization** - Separate concerns by config type
✅ **Validation** - Ensure configs exist before creating flows

## Usage

### Via API

```bash
# List connectors
curl http://localhost:3000/api/connectors

# Create flow using existing configs
curl -X POST http://localhost:3000/api/flows \
  -H "Content-Type: application/json" \
  -d '{
    "name": "my-flow",
    "connector_name": "nats-local",
    "destination_names": ["postgres-local"],
    "batch_size": 100
  }'
```

### Via Files

1. Edit YAML files in `config/` directory
2. Restart application to load changes
3. Or use hot-reload API (if enabled)

## Migration from Old Format

If you have old inline flow configs:

**Old format:**

```yaml
flows:
  - name: "my-flow"
    connector:
      type: "nats"
      config: { ... }
```

**Convert to new format:**

1. Extract connector to `connectors.yaml`
2. Extract destinations to `destinations.yaml`
3. Update flow to reference by name

See [`MIGRATION.md`](./MIGRATION.md) for detailed migration guide.
